package com.example.schoolmanagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchoolmanagementsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
